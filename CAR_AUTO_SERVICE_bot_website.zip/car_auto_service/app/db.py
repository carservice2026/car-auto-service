import sqlite3
from pathlib import Path

DB_PATH = Path("car_auto_service.db")

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with connect() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            language TEXT, name TEXT, phone TEXT, car TEXT,
            year TEXT, service TEXT, problem TEXT, preferred_time TEXT,
            status TEXT DEFAULT 'Yangi',
            telegram_user_id TEXT, telegram_username TEXT
        )''')
        con.execute('''CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            user_id TEXT, language TEXT, role TEXT, message TEXT
        )''')

def create_order(data):
    with connect() as con:
        cur = con.execute('''INSERT INTO orders
        (language,name,phone,car,year,service,problem,preferred_time,telegram_user_id,telegram_username)
        VALUES (?,?,?,?,?,?,?,?,?,?)''', (
            data.get("language"), data.get("name"), data.get("phone"),
            data.get("car"), data.get("year"), data.get("service"),
            data.get("problem"), data.get("preferred_time"),
            data.get("telegram_user_id"), data.get("telegram_username")
        ))
        return cur.lastrowid

def list_orders():
    with connect() as con:
        return [dict(r) for r in con.execute("SELECT * FROM orders ORDER BY id DESC").fetchall()]

def update_status(order_id, status):
    with connect() as con:
        con.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
