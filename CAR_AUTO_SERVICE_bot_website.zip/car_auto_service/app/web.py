from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from .db import init_db, list_orders, update_status, create_order
from .ai import answer_customer
from .config import ADMIN_USERNAME, ADMIN_PASSWORD, SERVICE_NAME, SERVICE_ADDRESS, SERVICE_PHONE\nfrom .notify import notify_admin_group

app=FastAPI(title=SERVICE_NAME)
app.add_middleware(SessionMiddleware, secret_key="CHANGE_THIS_SESSION_SECRET_BEFORE_DEPLOYMENT")
init_db()

STYLE = """<style>
body{margin:0;background:#101114;color:#f4f4f4;font:16px Arial}
header{padding:24px;background:#08090b;border-bottom:2px solid #c99b27}
main{max-width:1100px;margin:28px auto;padding:0 16px}
.card{background:#1c1e23;border:1px solid #383a40;border-radius:14px;padding:18px;margin:14px 0}
a,button{color:#111;background:#d8ad43;padding:9px 14px;border:0;border-radius:8px;text-decoration:none;cursor:pointer}
input,select{padding:10px;border-radius:7px;border:1px solid #555;background:#101114;color:white;margin:5px}
small{color:#c9a64b}.muted{color:#aaa}
table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:10px;border-bottom:1px solid #444}
</style>"""

def page(body):
    return HTMLResponse(f"<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>{STYLE}</head><body><header><b>⚙ {SERVICE_NAME}</b><div class='muted'>{SERVICE_ADDRESS} · {SERVICE_PHONE}</div></header><main>{body}</main></body></html>")

@app.get("/", response_class=HTMLResponse)
async def home():
    return page(f"<section class='card'><h1>CAR AUTO SERVICE</h1><p>Avtomobilingiz uchun professional xizmat.</p><p>{SERVICE_ADDRESS}</p><p>{SERVICE_PHONE}</p><a href='/booking'>Buyurtma qoldirish</a></section><section class='card'><h2>Xizmatlar</h2><p>Dvigatel · Hodovoy · Diagnostika · Moy almashtirish · Avtoelektrik · Kuzov ishlari</p></section>")

@app.get("/booking", response_class=HTMLResponse)
async def booking_form():
    return page("""<section class='card'><h2>Buyurtma / Заявка</h2><form method='post'>
    <input name='language' value='uz' type='hidden'><p><input name='name' placeholder='Ism / Имя' required></p>
    <p><input name='phone' placeholder='Telefon / Телефон' required></p><p><input name='car' placeholder='Avtomobil / Автомобиль' required></p>
    <p><input name='year' placeholder='Yili / Год'></p><p><select name='service'><option>Dvigatel ta'miri</option><option>Hodovoy ta'miri</option><option>Diagnostika</option><option>Moy almashtirish</option><option>Avtoelektrik</option><option>Kuzov ishlari</option><option>Другое</option></select></p>
    <p><input name='problem' placeholder='Muammo / Проблема' style='width:90%' required></p><p><input name='preferred_time' placeholder='Qachon kelasiz? / Когда приедете?'></p>
    <button type='submit'>Yuborish / Отправить</button></form></section>""")

@app.post("/booking")
async def submit_booking(name:str=Form(...), phone:str=Form(...), car:str=Form(...), year:str=Form(""),
                         service:str=Form(...), problem:str=Form(...), preferred_time:str=Form("")):
    order_id = create_order({"language":"uz","name":name,"phone":phone,"car":car,"year":year,
                  "service":service,"problem":problem,"preferred_time":preferred_time})
    await notify_admin_group(
        f"🆕 CAR AUTO SERVICE — SAYT BUYURTMASI #{order_id}\\n"
        f"Ism: {name}\\nTelefon: {phone}\\nAvtomobil: {car} ({year})\\n"
        f"Xizmat: {service}\\nMuammo: {problem}\\nKelish vaqti: {preferred_time}"
    )
    return page("<section class='card'><h2>Rahmat! Buyurtmangiz qabul qilindi.</h2><p>Administrator siz bilan bog'lanadi.</p></section>")

@app.get("/admin/login", response_class=HTMLResponse)
async def login():
    return page("""<section class='card'><h2>Administrator kirishi</h2><form method='post'>
    <p><input name='username' placeholder='Login'></p><p><input name='password' type='password' placeholder='Parol'></p>
    <button>Kirish</button></form></section>""")

@app.post("/admin/login")
async def do_login(request:Request, username:str=Form(...), password:str=Form(...)):
    if username != ADMIN_USERNAME or password != ADMIN_PASSWORD:
        raise HTTPException(401,"Login yoki parol xato")
    request.session["admin"]=True
    return RedirectResponse("/admin",status_code=303)

@app.get("/admin", response_class=HTMLResponse)
async def admin(request:Request):
    if not request.session.get("admin"): return RedirectResponse("/admin/login",status_code=303)
    rows=list_orders()
    body="<section class='card'><h2>Buyurtmalar paneli</h2><p>Jami buyurtmalar: %s</p><table><tr><th>#</th><th>Mijoz</th><th>Telefon</th><th>Avtomobil</th><th>Xizmat</th><th>Muammo</th><th>Holat</th><th></th></tr>" % len(rows)
    for r in rows:
        body += f"<tr><td>{r['id']}</td><td>{r['name']}</td><td>{r['phone']}</td><td>{r['car']}</td><td>{r['service']}</td><td>{r['problem']}</td><td>{r['status']}</td><td><form method='post' action='/admin/status'><input type='hidden' name='order_id' value='{r['id']}'><select name='status'><option>Yangi</option><option>Qabul qilindi</option><option>Jarayonda</option><option>Yakunlandi</option><option>Bekor qilindi</option></select><button>Saqlash</button></form></td></tr>"
    body += "</table><p><a href='/admin/logout'>Chiqish</a></p></section>"
    return page(body)

@app.post("/admin/status")
async def status(request:Request, order_id:int=Form(...), status:str=Form(...)):
    if not request.session.get("admin"): raise HTTPException(401,"Unauthorized")
    update_status(order_id,status)
    return RedirectResponse("/admin",status_code=303)

@app.get("/admin/logout")
async def logout(request:Request):
    request.session.clear()
    return RedirectResponse("/",status_code=303)

@app.get("/api/assistant")
async def assistant(q:str, lang:str="uz"):
    if lang not in ("uz","ru"): lang="uz"
    return {"answer":answer_customer(q,lang)}
