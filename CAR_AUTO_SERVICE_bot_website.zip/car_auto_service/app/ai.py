from openai import OpenAI
from .config import OPENAI_API_KEY, OPENAI_MODEL
from .knowledge import faq_answer

def answer_customer(text, lang="uz"):
    fallback = faq_answer(text, lang)
    if not OPENAI_API_KEY:
        return fallback
    try:
        client = OpenAI(api_key=OPENAI_API_KEY)
        language = "Uzbek" if lang == "uz" else "Russian"
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {"role":"system","content":(
                    f"You are the bilingual customer assistant for CAR AUTO SERVICE. Reply in {language}. "
                    "Be polite and concise. Explain services and help collect booking details. "
                    "Never claim a definite diagnosis from text/photos. Never invent prices, guarantees, "
                    "opening hours, or availability. For exact price and diagnosis, say a mechanic must inspect. "
                    "If there may be an immediate safety issue (brakes, steering, fuel smell, overheating), "
                    "advise the customer to stop driving when safe and contact a qualified mechanic."
                )},
                {"role":"user","content":text}
            ],
            max_tokens=220
        )
        return response.choices[0].message.content or fallback
    except Exception:
        return fallback
