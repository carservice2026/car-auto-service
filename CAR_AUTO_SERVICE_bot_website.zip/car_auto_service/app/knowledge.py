FAQ = {
    "uz": {
        "services": "Bizning xizmatlar: dvigatel ta'miri, hodovoy, diagnostika, moy almashtirish, avtoelektrik, kuzov ishlari va mayda ta'mir.",
        "price": "Narx avtomobil modeli va muammo turiga qarab belgilanadi. Aniq narxni usta ko'rik yoki diagnostikadan keyin aytadi.",
        "hours": "Ish vaqti va bo'sh vaqtni administrator tasdiqlaydi. Buyurtma qoldirsangiz, siz bilan bog'lanamiz.",
        "address": "Manzil: Sat tepo, 201, Samarqand. Telefon: +998 XX XXX XX XX.",
        "diagnostic": "Bot masofadan turib aniq tashxis qo'ya olmaydi. Muammoni yozing yoki rasm/video yuboring; usta tekshiruv kerakligini aytadi."
    },
    "ru": {
        "services": "Наши услуги: ремонт двигателя и ходовой части, диагностика, замена масла, автоэлектрик, кузовные и мелкие ремонтные работы.",
        "price": "Цена зависит от модели автомобиля и характера неисправности. Точную стоимость мастер назовет после осмотра или диагностики.",
        "hours": "Рабочее время и свободное время подтвердит администратор. Оставьте заявку, и мы свяжемся с вами.",
        "address": "Адрес: Sat tepo, 201, Самарканд. Телефон: +998 XX XXX XX XX.",
        "diagnostic": "Бот не может поставить точный диагноз удаленно. Опишите проблему или отправьте фото/видео; мастер подскажет, нужна ли проверка."
    }
}

def faq_answer(text, lang):
    t = text.lower()
    mapping = {
        "services": ["xizmat", "услуг", "что делаете", "nima qilasiz"],
        "price": ["narx", "qancha", "стоим", "цена", "сколько"],
        "hours": ["ish vaqt", "ochiq", "работ", "время"],
        "address": ["manzil", "adres", "адрес", "telefon", "номер"],
        "diagnostic": ["muammo", "ovoz", "shovqin", "diagnost", "неисправ", "стук", "шум"]
    }
    for key, words in mapping.items():
        if any(w in t for w in words):
            return FAQ.get(lang, FAQ["uz"])[key]
    if lang == "ru":
        return "Пожалуйста, опишите проблему, марку и модель автомобиля. Я помогу оформить заявку для мастера."
    return "Iltimos, muammoni hamda avtomobil markasi va modelini yozing. Usta uchun buyurtma rasmiylashtirishga yordam beraman."
