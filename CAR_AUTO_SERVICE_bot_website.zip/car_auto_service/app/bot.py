import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, ConversationHandler, ContextTypes, filters
from .config import BOT_TOKEN, ADMIN_GROUP_ID, SERVICE_NAME, SERVICE_ADDRESS, SERVICE_PHONE
from .db import create_order
from .ai import answer_customer

logging.basicConfig(level=logging.INFO)
LANG, NAME, PHONE, CAR, YEAR, SERVICE, PROBLEM, TIME = range(8)
TXT = {
 "uz": ["Assalomu alaykum! CAR AUTO SERVICE botiga xush kelibsiz. Tilni tanlang:", "🇺🇿 O'zbekcha", "🇷🇺 Русский",
        "Ismingizni yozing:", "Telefon raqamingizni yuboring yoki yozing:", "Avtomobil markasi va modelini yozing:",
        "Ishlab chiqarilgan yilini yozing (bilmasangiz, o'tkazib yuboring):",
        "Qaysi xizmat kerak?", "Muammoni batafsil yozing. Rasm yoki video ham yuborishingiz mumkin.",
        "Qachon kelmoqchisiz? (masalan, ertaga 10:00 yoki 'farqi yo'q')",
        "Rahmat! Buyurtmangiz qabul qilindi. Administrator siz bilan bog'lanadi."],
 "ru": ["Здравствуйте! Добро пожаловать в CAR AUTO SERVICE. Выберите язык:", "🇺🇿 O'zbekcha", "🇷🇺 Русский",
        "Напишите ваше имя:", "Отправьте или введите номер телефона:", "Марка и модель автомобиля:",
        "Год выпуска (если не знаете, пропустите):", "Какая услуга нужна?",
        "Опишите проблему подробно. Также можно отправить фото или видео.",
        "Когда хотите приехать? (например, завтра в 10:00 или «без разницы»)",
        "Спасибо! Заявка принята. Администратор свяжется с вами."]
}
SERVICES = {
 "uz": ["Dvigatel ta'miri","Hodovoy ta'miri","Diagnostika","Moy almashtirish","Avtoelektrik","Kuzov ishlari","Boshqa"],
 "ru": ["Ремонт двигателя","Ремонт ходовой","Диагностика","Замена масла","Автоэлектрик","Кузовные работы","Другое"]
}
def kb(items): return ReplyKeyboardMarkup([[KeyboardButton(x)] for x in items], resize_keyboard=True)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text(TXT["uz"][0], reply_markup=kb(TXT["uz"][1:3]))
    return LANG

async def choose_lang(update, context):
    lang = "ru" if "Русский" in update.message.text else "uz"
    context.user_data["language"] = lang
    await update.message.reply_text(TXT[lang][3])
    return NAME

async def name(update, context):
    context.user_data["name"] = update.message.text
    lang=context.user_data["language"]
    await update.message.reply_text(TXT[lang][4], reply_markup=ReplyKeyboardMarkup(
        [[KeyboardButton("📱 Telefon raqamni yuborish", request_contact=True)]], resize_keyboard=True))
    return PHONE

async def phone(update, context):
    context.user_data["phone"] = update.message.contact.phone_number if update.message.contact else update.message.text
    lang=context.user_data["language"]
    await update.message.reply_text(TXT[lang][5])
    return CAR

async def car(update, context):
    context.user_data["car"] = update.message.text
    lang=context.user_data["language"]
    await update.message.reply_text(TXT[lang][6])
    return YEAR

async def year(update, context):
    context.user_data["year"] = update.message.text
    lang=context.user_data["language"]
    await update.message.reply_text(TXT[lang][7], reply_markup=kb(SERVICES[lang]))
    return SERVICE

async def service(update, context):
    context.user_data["service"] = update.message.text
    lang=context.user_data["language"]
    await update.message.reply_text(TXT[lang][8])
    return PROBLEM

async def problem(update, context):
    context.user_data["problem"] = update.message.text
    lang=context.user_data["language"]
    await update.message.reply_text(TXT[lang][9])
    return TIME

async def preferred_time(update, context):
    context.user_data["preferred_time"] = update.message.text
    d=context.user_data
    order_id=create_order({
      **d, "telegram_user_id": str(update.effective_user.id),
      "telegram_username": update.effective_user.username or ""
    })
    lang=d["language"]
    await update.message.reply_text(TXT[lang][10], reply_markup=ReplyKeyboardMarkup([["/start"]], resize_keyboard=True))
    if ADMIN_GROUP_ID:
        msg = (f"🆕 CAR AUTO SERVICE — BUYURTMA #{order_id}\n"
               f"Til: {lang}\nIsm: {d.get('name')}\nTelefon: {d.get('phone')}\n"
               f"Avtomobil: {d.get('car')} ({d.get('year')})\nXizmat: {d.get('service')}\n"
               f"Muammo: {d.get('problem')}\nKelish vaqti: {d.get('preferred_time')}\n"
               f"Telegram: @{update.effective_user.username or 'username yoq'}")
        try: await context.bot.send_message(chat_id=int(ADMIN_GROUP_ID), text=msg)
        except Exception: logging.exception("Admin group notification failed")
    context.user_data.clear()
    return ConversationHandler.END

async def help_ai(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lang=context.user_data.get("language","uz")
    reply=answer_customer(update.message.text, lang)
    await update.message.reply_text(reply)

async def cancel(update, context):
    await update.message.reply_text("Bekor qilindi. /start orqali qayta boshlashingiz mumkin.")
    context.user_data.clear()
    return ConversationHandler.END

def run_bot():
    if not BOT_TOKEN:
        raise RuntimeError("TELEGRAM_BOT_TOKEN .env faylida kiritilmagan")
    app=Application.builder().token(BOT_TOKEN).build()
    conv=ConversationHandler(
      entry_points=[CommandHandler("start", start)],
      states={
       LANG:[MessageHandler(filters.TEXT & ~filters.COMMAND, choose_lang)],
       NAME:[MessageHandler(filters.TEXT & ~filters.COMMAND, name)],
       PHONE:[MessageHandler((filters.TEXT | filters.CONTACT) & ~filters.COMMAND, phone)],
       CAR:[MessageHandler(filters.TEXT & ~filters.COMMAND, car)],
       YEAR:[MessageHandler(filters.TEXT & ~filters.COMMAND, year)],
       SERVICE:[MessageHandler(filters.TEXT & ~filters.COMMAND, service)],
       PROBLEM:[MessageHandler(filters.TEXT & ~filters.COMMAND, problem)],
       TIME:[MessageHandler(filters.TEXT & ~filters.COMMAND, preferred_time)]
      }, fallbacks=[CommandHandler("cancel", cancel)])
    app.add_handler(conv)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, help_ai))
    app.run_polling()
