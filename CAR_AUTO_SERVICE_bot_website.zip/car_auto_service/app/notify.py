from telegram import Bot
from .config import BOT_TOKEN, ADMIN_GROUP_ID

async def notify_admin_group(text: str):
    if not BOT_TOKEN or not ADMIN_GROUP_ID:
        return False
    try:
        bot = Bot(token=BOT_TOKEN)
        async with bot:
            await bot.send_message(chat_id=int(ADMIN_GROUP_ID), text=text)
        return True
    except Exception:
        return False
