import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
ADMIN_GROUP_ID = os.getenv("ADMIN_GROUP_ID", "")
ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-this-password")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:8000")
SERVICE_NAME = os.getenv("SERVICE_NAME", "CAR AUTO SERVICE")
SERVICE_ADDRESS = os.getenv("SERVICE_ADDRESS", "Sat tepo, 201, Samarqand")
SERVICE_PHONE = os.getenv("SERVICE_PHONE", "+998 XX XXX XX XX")
