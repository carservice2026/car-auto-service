# CAR AUTO SERVICE — Telegram bot + veb-sayt

## Nimalar bor?
- Telegram bot: o'zbekcha/ruscha til tanlash, xizmat tanlash, mijoz ma'lumotlari va muammoni yig'ish.
- Buyurtmalar SQLite bazasiga saqlanadi.
- Telegram administrator guruhiga yangi buyurtma xabari yuboriladi.
- Veb-sayt: xizmatlar sahifasi va buyurtma formasi.
- Admin panel: buyurtmalarni ko'rish va holatini yangilash.
- Ixtiyoriy AI javoblari: OpenAI API kaliti kiritilsa ishlaydi; kalit bo'lmasa FAQ javoblari ishlaydi.

## 1. Kerak bo'ladi
Python 3.10 yoki yangiroq, Telegram akkaunt.

## 2. Bot yaratish
1. Telegram'da `@BotFather` ga kiring.
2. `/newbot` yuboring va bot nomi hamda username tanlang.
3. BotFather bergan tokenni saqlang.
4. Administratorlar uchun Telegram guruh yarating.
5. Botni guruhga qo'shing. Guruh ID sini olish uchun botni guruhga qo'shib, kerak bo'lsa guruhda bir xabar yuboring va Telegram bot API `getUpdates` orqali `chat.id` ni aniqlang. Guruh ID odatda `-100...` bilan boshlanadi.

## 3. Sozlash
1. `.env.example` faylidan nusxa olib `.env` nomlang.
2. `TELEGRAM_BOT_TOKEN`, `ADMIN_GROUP_ID` va admin parolini kiriting.
3. `SERVICE_PHONE` va `SERVICE_ADDRESS` ni haqiqiy ma'lumotlaringizga almashtiring.
4. AI kerak bo'lsa `OPENAI_API_KEY` kiriting. AI kaliti pullik API hisobiga bog'liq bo'lishi mumkin. Kalitni hech kimga yubormang.

## 4. O'rnatish
Terminalda loyiha papkasiga o'tib:
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

## 5. Ishga tushirish
Veb-sayt va admin panel:
```bash
python run_web.py
```
Brauzerda `http://127.0.0.1:8000` oching. Admin: `http://127.0.0.1:8000/admin/login`.

Telegram bot (ikkinchi terminalda):
```bash
python run_bot.py
```

## Muhim xavfsizlik
- Internetga chiqarishdan oldin `app/web.py` ichidagi `CHANGE_THIS_SESSION_SECRET_BEFORE_DEPLOYMENT` ni uzun tasodifiy maxfiy qiymatga almashtiring.
- Kuchli admin paroli ishlating.
- Saytni HTTPS bilan joylashtiring.
- `.env` faylini hech qachon GitHub yoki boshqalarga yubormang.
- Bu boshlang'ich MVP: production uchun rate limiting, spam himoyasi, backup, log monitoring va CSRF himoyasi qo'shish tavsiya qilinadi.
- Botning javoblari umumiy ma'lumot. Masofadan turib aniq tashxis qo'ymaydi; xavfsizlikka taalluqli nosozliklarda ustaga murojaat qilish kerak.

## Keyingi sozlash
Bot tokeni, guruh ID, telefon raqami va manzil kiritilgach sinov buyurtmasi yuboring. Buyurtma bazaga tushishi va admin guruhiga kelishini tekshiring.
